# Chapterhouse — Live Fast Kit

This is a drop-in Next.js starter tweaked from the working **BFF Widget → Supabase → GitHub/Netlify** playbook. It includes:
- Floating assistant widget that logs to `public.bff_notes` (two rows per send)
- Memory smoke-test page
- Netlify config (plugin-based Next.js build)
- Safe Supabase client (no session persistence; custom storage key)
- Dev port set to **3003** to avoid conflicts

## 1) Setup
```bash
cp .env.example .env.local
# paste your Supabase URL + anon (Project Settings → API)
npm install
npm run dev    # http://localhost:3003
```

## 2) Database (Dev)
In Supabase SQL Editor, create the table and permissive dev RLS policies (tighten for prod):
```sql
create table if not exists public.bff_notes (
  id bigint generated always as identity primary key,
  content text,
  created_at timestamp with time zone default now()
);

alter table public.bff_notes enable row level security;

create policy "anon can read bff_notes (dev)"
  on public.bff_notes for select to anon using (true);

create policy "anon can insert bff_notes (dev)"
  on public.bff_notes for insert to anon with check (true);
```

## 3) Deploy (Netlify)
- Connect this repo in Netlify (reads `netlify.toml` automatically), or
- Drag the `chapterhouse` folder to https://app.netlify.com/drop

## 4) Pages
- `/` — links
- `/memory` — connect / save / refresh viewer
- `/widget` — renders the floating widget (FAB at bottom-right)

## 5) Troubleshooting
- **Missing env**: set `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` in `.env.local`
- **GoTrue client warning**: we reuse a single client and disable session persistence
- **Port conflicts**: dev runs on **3003**

---
Generated 2025-08-11T10:10:51
