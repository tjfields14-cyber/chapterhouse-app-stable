import Link from 'next/link'

export default function Home() {
  const hasEnv = !!process.env.NEXT_PUBLIC_SUPABASE_URL && !!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
  return (
    <main style={{padding:24, fontFamily:'ui-sans-serif, system-ui'}}>
      <h1>Chapterhouse — Live Fast</h1>
      <p>Quick links based on the working Playbook path.</p>
      <ul>
        <li><Link href="/memory">Memory smoke test</Link></li>
        <li><Link href="/widget">Assistant widget</Link></li>
      </ul>
      {!hasEnv && (
        <p style={{color:'#b45309', background:'#fffbeb', padding:12, border:'1px solid #f59e0b'}}>
          Env missing. Add <code>.env.local</code> with NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY.
        </p>
      )}
      <p style={{marginTop:24, opacity:.7}}>Run: <code>npm run dev</code> (port 3003)</p>
    </main>
  )
}
